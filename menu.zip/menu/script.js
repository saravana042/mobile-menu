$(document).ready(function() {
	
	/** MOBILE MENU **/
	
	$('#mobile-menu-icon').on("click",function() {
		if(!$(this).hasClass('open')){
			$(this).addClass('open');
			$('#mobile-menu').addClass('menu-open');
			$('.mobile-menu-overlay').show();
		}
		else{
			$(this).removeClass('open');
			$('#mobile-menu').removeClass('menu-open');
			$('.mobile-menu-overlay').hide();
		}	
	});
	
	
	/** MOBILE SUB MENU **/
	
	var rwdMenu = $('.rwd-menu'),
	topMenu = $('.rwd-menu > li > a'),
	topSubMenu = $('.rwd-menu > li > ul > li > a'),
	parentLi = $('.rwd-menu > li'),
	parentLisubMenu = $('.rwd-menu > li > ul > li'),
	backBtn = $('.back-btn'),
	subMenubackBtn = $('.back-btn2');

	topMenu.on('click',function(e){
		var thisTopMenu = $(this).parent(); // current $this
		rwdMenu.addClass('rwd-menu-view');
		parentLi.removeClass('open-submenu');
		thisTopMenu.addClass('open-submenu'); 
	});
	
	topSubMenu.on('click',function(e){
		var thisTopMenu = $(this).parent();
		parentLisubMenu.removeClass('open-submenu2');
		thisTopMenu.addClass('open-submenu2'); 
	});

	backBtn.click(function(){
		var thisBackBtn = $(this);
		parentLi.removeClass();
		rwdMenu.removeClass('rwd-menu-view');
	});
	
	subMenubackBtn.click(function(){
		var thisBackBtn = $(this);
		parentLisubMenu.removeClass();
	});
	
	
	/** MOBILE MENU CLICK OUTSIDE CLOSE **/
	
	$("html").click(function(event) {
		if ($(event.target).closest('#menu-side, #mobile-menu').length === 0) {
			$('#mobile-menu-icon').removeClass('open');
			$('#mobile-menu').removeClass('menu-open');
			$('.mobile-menu-overlay').hide();
		}
	});

});
